/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author Embit-E7450
 */
public class Staff extends Person implements PayRoll{

    private String duty;
    private int workLoad;
    //maybe implented in the person class since both of the classes are using it 
    //ask if u have the work hour in person it also capable of being use in full time and part time or i have to create workhour in full and part

    public Staff(String duty, int workLoad, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {
        super(Fname, Lname, PhoneNumber, Salary, adress, workHour);
        this.duty = duty;
        this.workLoad = workLoad;
    }
    public Staff(){
         super();
    }

    public int IncriseHourWork() {
        if (getworkHour() < 3) {
            return getworkHour() + 1;
        } else {
            return getworkHour();
        }
    }

    public int IncriseSalary() {
        int percentage = 5;
        if (getworkHour() > 8) {
            return getSalary() + (getSalary() * (percentage / 100));
        } else {
            return getSalary();
        }
       
    }
    public double ComputePayRoll(){
       
     return (getWorkLoad()*32*2)*0.75 ;  
       
   }
    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public int getWorkLoad() {
        return workLoad;
    }

    public void setWorkLoad(int workLoad) throws workLoadError{
        if(workLoad>40){
            throw new workLoadError(workLoad);
        }else
        this.workLoad = workLoad;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Staff other = (Staff) obj;
        if (this.workLoad != other.workLoad) {
            return false;
        }
        if (!Objects.equals(this.duty, other.duty)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {                                          //String duty, int workLoad, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour
    return "Staff{" + "duty=" + getDuty() + ", workLoad=" + getWorkLoad() + ", Fname=" + getFname() + ", Lname=" + getLname() +  ", phone number=" + getPhoneNumber() + ", salary=" + getSalary() + ", adress=" + getAdress() + ", workHour=" + getworkHour() + '}';
    }

}
