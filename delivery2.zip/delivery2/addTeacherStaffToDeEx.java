/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

/**
 *
 * @author Embit-E7450
 */
public class addTeacherStaffToDeEx extends Exception{

    public addTeacherStaffToDeEx() {
        super("error");
    }

    public addTeacherStaffToDeEx(int  id) {
        super("The teacher or staff that you are trying to add it dosent exist");
    }
    
}
