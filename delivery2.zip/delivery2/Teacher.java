/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

import java.util.Objects;

/**
 *
 * @author Embit-E7450
 */
public class Teacher extends Person {

    private String Speciality;
    private String Degree;
    private double DegreeRate;

    public Teacher(String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {
        super(Fname, Lname, PhoneNumber, Salary, adress, workHour);
        this.Speciality = Speciality;
        this.Degree = Degree;
        this.DegreeRate = DegreeRate;
    }

   
   

   

    public int IncriseHourWork() {
        if (getworkHour() < 3) {
            return getworkHour() + 1;
        } else {
            return getworkHour();
        }
    }

    public int IncriseSalary() {
        int percentage = 5;
        if (getworkHour() > 8) {
            return getSalary() + (getSalary() * (percentage / 100));
        } else {
            return getSalary();
        }
    }

   

    public String getSpeciality() {
        return Speciality;
    }

    public void setSpeciality(String Speciality) {
        this.Speciality = Speciality;
    }

    public String getDegree() {
        return Degree;
    }

    public void setDegree(String Degree) {
        this.Degree = Degree;
    }
     public double getDegreeRate() {
        return DegreeRate;
    }

    public void setDegreeRate(double DegreeRate) {
        this.DegreeRate = DegreeRate;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Teacher other = (Teacher) obj;
        if (Double.doubleToLongBits(this.DegreeRate) != Double.doubleToLongBits(other.DegreeRate)) {
            return false;
        }
        if (!Objects.equals(this.Speciality, other.Speciality)) {
            return false;
        }
        if (!Objects.equals(this.Degree, other.Degree)) {
            return false;
        }
        return true;
    }

  

    @Override
    public String toString() {                                                                                                                                             
        return "Teacher{" + "Speciality=" + Speciality + ", Degree=" + Degree + ", DegreeRate=" + DegreeRate + ", Fname=" + getFname() + ", Lname=" + getLname() +", Phone Number=" + getPhoneNumber() +", adress=" + getAdress() +", Work Hour=" + getworkHour() + '}';
    }

   
   

   

}
