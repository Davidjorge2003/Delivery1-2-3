/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

import java.util.Objects;

/**
 *
 * @author Embit-E7450
 */

public abstract class Person {
    private String Fname;
    private String Lname;
    private int PhoneNumber;
    private int Salary;
    private String adress;
    private int  workHour;

    public Person(String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.PhoneNumber = PhoneNumber;
        this.Salary = Salary;
        this.adress = adress;
        this.workHour=workHour;
    }
public Person(){
    
}
    
    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }
        public int getworkHour() {
        return workHour;
    }

    public void setWorkHour(int worHour) {
        this.workHour=workHour;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (this.PhoneNumber != other.PhoneNumber) {
            return false;
        }
        if (this.Salary != other.Salary) {
            return false;
        }
        if (!Objects.equals(this.Fname, other.Fname)) {
            return false;
        }
        if (!Objects.equals(this.Lname, other.Lname)) {
            return false;
        }
        if (!Objects.equals(this.adress, other.adress)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Person{" + "Fname=" + Fname + ", Lname=" + Lname + ", PhoneNumber=" + PhoneNumber + ", Salary=" + Salary + ", adress=" + adress + '}';
    }
   public abstract int IncriseSalary(); 
   public abstract int IncriseHourWork(); 
}
