/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

/**
 *
 * @author Embit-E7450
 */
public class FullTime extends Teacher implements PayRoll {

    public FullTime(String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {
        super(Speciality, Degree, DegreeRate, Fname, Lname, PhoneNumber, Salary, adress, workHour);
    }

    public double ComputePayRoll() {

        if (getDegree() == "PhD") {
            setDegreeRate(112);
        } else if (getDegree() == "Master") {
            setDegreeRate(82);
        } else {
            if (getDegree() == "Bachelor") {
                setDegreeRate(42);
            }

        }
        return (32 * getDegreeRate() * 2) * 0.85;

    }

    public int countWorked() {//maybe add that if he works less than x time decress and if is part time increse hour work       
        if(getworkHour() < 12){
            return getworkHour() + 1;
        } else {
            return getworkHour();
    }
    }
}


