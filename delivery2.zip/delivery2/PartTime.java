/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

/**
 *
 * @author Embit-E7450
 */
public class PartTime extends Teacher implements PayRoll {

    public PartTime(String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {
        super(Speciality, Degree, DegreeRate, Fname, Lname, PhoneNumber, Salary, adress, workHour);
    }

    

    public double ComputePayRoll() {

        if (getDegree() == "PhD") {
            setDegreeRate(112);
        } else if (getDegree() == "Master") {
            setDegreeRate(82);
        } else {
            if (getDegree() == "Bachelor") {
             setDegreeRate(42);
        }
        
        }
        return (getworkHour()*getDegreeRate()*2)*0.76;
       
   
    }    

    public int countHourWork() {
        if(getworkHour() > 12){
            return getworkHour() -1;
        } else {
            return getworkHour();
    }
    }
}
