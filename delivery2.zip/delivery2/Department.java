/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

import java.io.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Embit-E7450
 */
//how do i use this in the classes teacher and staff and then how do i implement this to the 
//exception
public class Department  implements Serializable {

    int id;
    Teacher dean;
    ArrayList<Teacher> Teachers = new ArrayList<Teacher>();
    ArrayList<Staff> Staffs = new ArrayList<Staff>();

    //String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour
    public Department(int id, Teacher dean, String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {       
        this.id = id;
        this.dean = dean;
    }
 public Department(int id,String duty, int workLoad, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour) {
        this.id = id;
        this.dean = dean;
    }
    public String readFile(String path) throws FileNotFoundException, IOException {
        File f = new File(path);
        BufferedReader br = new BufferedReader(new FileReader(f));

        StringBuilder fileContent = new StringBuilder();
        String st;
        while ((st = br.readLine()) != null) {
            fileContent.append(st);

        }

        return fileContent.toString();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) throws addTeacherStaffToDeEx {
        if (getId() == getId()) {
            throw new addTeacherStaffToDeEx(id);
        }
        this.id = id;
    }

    public Teacher getDean() {
        return dean;
    }

    public void setDean(Teacher dean) throws DeanDepartmentEx {
        if ((Teachers.equals(dean)) == false) {
            throw new DeanDepartmentEx(dean);
        }
        this.dean = dean;
    }

    public ArrayList<Teacher> getTeachers() {
        return Teachers;
    }

    public void setTeacher(ArrayList<Teacher> Teachers) throws addTeacherEx {
        if (getId() == getId()) {
            throw new addTeacherEx(Teachers);
        }
        this.Teachers=Teachers;
    }

    public ArrayList<Staff> getStaffs() {
        return Staffs;
    }

    public void setStaff(ArrayList<Staff> Staffs) throws addStaffEx {
        if (getId() == getId()) {
            throw new addStaffEx(Staffs);
        }

    }

    @Override
    public String toString() {
        return "Department{" + "id=" + id + ", dean=" + dean + ", Teachers=" + Teachers + ", Staffs=" + Staffs + '}';
    }

}
