/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

import java.util.ArrayList;

/**
 *
 * @author Embit-E7450
 */
public class addTeacherEx extends Exception{

    public addTeacherEx() {
        super("Error");
    }

    public addTeacherEx(ArrayList<Teacher> Teachers) {
        super("The teacher that your are trying to add is reapited. Try againg pls");
    }
    
}
