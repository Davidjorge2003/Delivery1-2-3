/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package delivery2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Embit-E7450
 */
public class Delivery2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        File f = new File("h.txt");
        FileWriter fw = new FileWriter(f);
        PrintWriter pw = new PrintWriter(fw);

        System.out.println("What do you want to add? Teacher or Staff");
        String Type = sc.nextLine();

        if ("Teacher".equals(Type)) {
            System.out.println("What is your Speciality");
            String Speciality = sc.nextLine();
            System.out.println("what is your Degree?");
            String Degree = sc.nextLine();
            System.out.println("what is your name?");
            String Fname = sc.nextLine();
            System.out.println("what is your last name?");
            String Lname = sc.nextLine();
            System.out.println("what is your PhoneNumber");
            int PhoneNumber = sc.nextInt();
            System.out.println("what is your salary?");
            int Salary = sc.nextInt();
            System.out.println("what is your adress?");
            String adress = sc.nextLine();
            System.out.println("how many Hours do u work?");
            int HourWork = sc.nextInt();
            Teacher a = new Teacher(Speciality, Degree, 0, Fname, Lname, PhoneNumber, Salary, adress, HourWork);

            System.out.println("what is your id?");
            int id = sc.nextInt();
            //int id, Teacher dean, String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour
            Department b = new Department(id, a, a.getSpeciality(), a.getDegree(), (int) a.getDegreeRate(), a.getFname(), a.getFname(), a.getPhoneNumber(), a.getSalary(), a.getAdress(), a.getworkHour());
            b.Teachers.add(a);
            pw.println(a);
            pw.close();
            
            try{
                b.setId(id);
            }catch(addTeacherStaffToDeEx e){
                e.getMessage();
            }

        } else if ("Staff".equals(Type)) {

            System.out.println("what is your duty?");
            String duty = sc.nextLine();
            System.out.println("what is the workload?");
            int WorkLoad = sc.nextInt();
            System.out.println();
            String a = sc.nextLine();
            System.out.println("what is your name?");
            String SFname = sc.nextLine();
            System.out.println("wta is your Last name?");
            String SLname = sc.nextLine();
            System.out.println("what is your phoneNUmber ");
            int PhoneNumber = sc.nextInt();
            System.out.println("what is your salary?");
            int SSalary = sc.nextInt();
            System.out.println("what is your adress?");
            String adress = sc.nextLine();
            System.out.println("how many hours do u work?");
            int SWorkHour = sc.nextInt();
            Staff c = new Staff(duty, WorkLoad, SFname, SLname, PhoneNumber, SSalary, adress, SWorkHour);
            System.out.println("what is your id?");
            int id = sc.nextInt();
//(int id, Teacher dean, String Speciality, String Degree, int DegreeRate, String Fname, String Lname, int PhoneNumber, int Salary, String adress, int workHour
            Department b = new Department(id, duty, WorkLoad, SFname, SLname, PhoneNumber, SSalary, adress, SWorkHour);
            b.Staffs.add(c);
            pw.println(c);
            pw.close();
            try {
                c.setWorkLoad(WorkLoad);

            } catch (workLoadError e) {
                e.getMessage();
            }

        }
        

    }

}
