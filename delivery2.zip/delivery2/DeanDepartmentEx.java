/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

/**
 *
 * @author Embit-E7450
 */
public class DeanDepartmentEx extends Exception{

    public DeanDepartmentEx() {
        System.out.println("Error");
    }

    public DeanDepartmentEx(Teacher dean) {
        super("Dean is meassing in departmen class. Pls try againg");
    }
    
}
