/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

/**
 *
 * @author Embit-E7450
 */
interface PayRoll {

    double ComputePayRoll();

}
//full time teacher 
//public double ComputePayRoll(){
//       if (degree=="PhD") {
//         degree=112;
//}else if(degree=="Master"){
//   degree=82;
//}else(if degree=="Bachelor"){
//degree=42;
//}
//getSalary()=(32*degree*2)*0.85     
//   }
////part-time
//public double ComputePayRoll(){
//       if (degree=="PhD") {
//         degree=112;
//}else if(degree=="Master"){
//   degree=82;
//}else(if degree=="Bachelor"){
//degree=42;
//}
//getSalary()=(hoursworked*degree*2)*0.76    
//   }
//
//////staff
////public int ComputePayRoll(){
////  
////getSalary()=(getWorlLoad()*32*2)*0.75     
////   }
