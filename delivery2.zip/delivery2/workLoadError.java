/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package delivery2;

/**
 *
 * @author Embit-E7450
 */
public class workLoadError extends Exception{

    public workLoadError() {
    }

    public workLoadError(int workLoad) {
        super("The work load is higher than 40 pls try again.Thanks");
    }
    
}
